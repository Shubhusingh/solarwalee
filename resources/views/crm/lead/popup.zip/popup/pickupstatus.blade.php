 <div class="modal-content">
      <div class="modal-header" style="background-color: #c23321;">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <form action="{{url('/lead/interest/store2')}}" method="post">
            @csrf
        <input type="hidden" value={{$id}} name="id" >
 <input type="radio" name="vehicle3" value="Not Pickup">
  <label for="radio">Not Pickup</label>
  
  
    <input type="radio"  name="vehicle3" value="Not Reachable">
  <label for="radio"> Not Reachable</label>
  
   <input type="radio" name="vehicle3" value="Not Available">
  <label for="radio">Not Available</label>
  
 
  <br><br>
  <input type="submit" class="btn btn-primary" value="Update" style="float: inline-end;
    background-color: #c23321;"> 
</div>
      
      
       
        </form>
    </div>
  </div>